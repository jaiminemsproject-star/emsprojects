<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class HrLeavePolicy extends Model
{
    protected $table = 'hr_leave_policies';

    protected $fillable = [
        'company_id',
        'code',
        'name',
        'description',
        'leave_year_type',
        'year_start_date',
        'allow_leave_in_probation',
        'probation_allowed_leave_types',
        'allow_backdated_application',
        'max_backdate_days',
        'allow_future_application',
        'max_future_days',
        'sandwich_rule_enabled',
        'sandwich_min_gap_days',
        'approval_levels',
        'skip_level_on_absence',
        'is_default',
        'is_active',
    ];

    protected $casts = [
        'year_start_date' => 'date',
        'probation_allowed_leave_types' => 'array',
        'allow_leave_in_probation' => 'boolean',
        'allow_backdated_application' => 'boolean',
        'allow_future_application' => 'boolean',
        'sandwich_rule_enabled' => 'boolean',
        'skip_level_on_absence' => 'boolean',
        'is_default' => 'boolean',
        'is_active' => 'boolean',
        'max_backdate_days' => 'integer',
        'max_future_days' => 'integer',
        'sandwich_min_gap_days' => 'integer',
        'approval_levels' => 'integer',
    ];

    // ==================== RELATIONSHIPS ====================

    public function employees(): HasMany
    {
        return $this->hasMany(HrEmployee::class, 'hr_leave_policy_id');
    }

    public function details(): HasMany
    {
        return $this->hasMany(HrLeavePolicyDetail::class, 'hr_leave_policy_id');
    }

    public function leaveTypes(): BelongsToMany
    {
        return $this->belongsToMany(HrLeaveType::class, 'hr_leave_policy_details', 'hr_leave_policy_id', 'hr_leave_type_id')
            ->withPivot(['days_per_year', 'max_carry_forward', 'allow_encashment'])
            ->withTimestamps();
    }

    // ==================== SCOPES ====================

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeDefault($query)
    {
        return $query->where('is_default', true);
    }

    // ==================== ACCESSORS ====================

    public function getLeaveYearLabelAttribute(): string
    {
        return match($this->leave_year_type) {
            'calendar' => 'Calendar Year (Jan-Dec)',
            'financial' => 'Financial Year (Apr-Mar)',
            'custom' => 'Custom (' . ($this->year_start_date?->format('d M') ?? '-') . ')',
            default => ucfirst($this->leave_year_type),
        };
    }
}
