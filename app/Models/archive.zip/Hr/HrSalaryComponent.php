<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class HrSalaryComponent extends Model
{
    protected $table = 'hr_salary_components';

    protected $fillable = [
        'company_id',
        'code',
        'name',
        'short_name',
        'type',
        'category',
        'calculation_type',
        'calculation_value',
        'based_on',
        'formula',
        'is_taxable',
        'is_statutory',
        'statutory_type',
        'affects_pf',
        'affects_esi',
        'affects_pt',
        'affects_gratuity',
        'max_limit',
        'sort_order',
        'is_active',
    ];

    protected $casts = [
        'calculation_value' => 'decimal:2',
        'max_limit' => 'decimal:2',
        'is_taxable' => 'boolean',
        'is_statutory' => 'boolean',
        'affects_pf' => 'boolean',
        'affects_esi' => 'boolean',
        'affects_pt' => 'boolean',
        'affects_gratuity' => 'boolean',
        'is_active' => 'boolean',
        'sort_order' => 'integer',
    ];

    // ==================== RELATIONSHIPS ====================

    public function salaryStructures(): BelongsToMany
    {
        return $this->belongsToMany(HrSalaryStructure::class, 'hr_salary_structure_components')
            ->withPivot(['calculation_type', 'calculation_value', 'is_active'])
            ->withTimestamps();
    }

    // ==================== SCOPES ====================

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeOrdered($query)
    {
        return $query->orderBy('sort_order')->orderBy('name');
    }

    public function scopeEarnings($query)
    {
        return $query->where('type', 'earning');
    }

    public function scopeDeductions($query)
    {
        return $query->where('type', 'deduction');
    }

    public function scopeStatutory($query)
    {
        return $query->where('is_statutory', true);
    }

    // ==================== ACCESSORS ====================

    public function getTypeLabelAttribute(): string
    {
        return match($this->type) {
            'earning' => 'Earning',
            'deduction' => 'Deduction',
            'employer_contribution' => 'Employer Contribution',
            default => ucfirst($this->type ?? '-'),
        };
    }

    public function getTypeColorAttribute(): string
    {
        return match($this->type) {
            'earning' => 'success',
            'deduction' => 'danger',
            'employer_contribution' => 'info',
            default => 'secondary',
        };
    }

    public function getCategoryLabelAttribute(): string
    {
        return match($this->category) {
            'basic' => 'Basic',
            'allowance' => 'Allowance',
            'reimbursement' => 'Reimbursement',
            'statutory' => 'Statutory',
            'other' => 'Other',
            default => ucfirst($this->category ?? '-'),
        };
    }

    public function getCalculationTypeLabelAttribute(): string
    {
        return match($this->calculation_type) {
            'fixed' => 'Fixed Amount',
            'percentage' => 'Percentage',
            'formula' => 'Formula',
            default => ucfirst($this->calculation_type ?? '-'),
        };
    }

    // ==================== METHODS ====================

    /**
     * Calculate component value based on base amount
     */
    public function calculateValue(float $baseAmount): float
    {
        return match($this->calculation_type) {
            'fixed' => $this->calculation_value,
            'percentage' => $baseAmount * ($this->calculation_value / 100),
            'formula' => $this->evaluateFormula($baseAmount),
            default => 0,
        };
    }

    /**
     * Evaluate formula (basic implementation)
     */
    protected function evaluateFormula(float $baseAmount): float
    {
        // Simple formula evaluation - can be extended
        $formula = str_replace('{base}', $baseAmount, $this->formula ?? '0');
        return eval("return {$formula};") ?? 0;
    }
}
