@extends('layouts.erp')

@section('title', 'Salary Components')

@section('content')
<div class="container-fluid py-3">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h4 class="mb-1">Salary Components</h4>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 small">
                    <li class="breadcrumb-item"><a href="{{ route('hr.dashboard') }}">HR</a></li>
                    <li class="breadcrumb-item active">Salary Components</li>
                </ol>
            </nav>
        </div>
        <a href="{{ route('hr.salary-components.create') }}" class="btn btn-primary btn-sm">
            <i class="bi bi-plus-lg me-1"></i> Add Component
        </a>
    </div>

    @include('partials.flash')

    <div class="card">
        <div class="card-header bg-light py-2">
            <form method="GET" class="row g-2 align-items-center">
                <div class="col-auto">
                    <input type="text" name="search" class="form-control form-control-sm" 
                           placeholder="Search..." value="{{ request('search') }}">
                </div>
                <div class="col-auto">
                    <select name="type" class="form-select form-select-sm">
                        <option value="">All Types</option>
                        <option value="earning" {{ request('type') === 'earning' ? 'selected' : '' }}>Earning</option>
                        <option value="deduction" {{ request('type') === 'deduction' ? 'selected' : '' }}>Deduction</option>
                        <option value="employer_contribution" {{ request('type') === 'employer_contribution' ? 'selected' : '' }}>Employer Contribution</option>
                    </select>
                </div>
                <div class="col-auto">
                    <select name="is_active" class="form-select form-select-sm">
                        <option value="">All Status</option>
                        <option value="1" {{ request('is_active') === '1' ? 'selected' : '' }}>Active</option>
                        <option value="0" {{ request('is_active') === '0' ? 'selected' : '' }}>Inactive</option>
                    </select>
                </div>
                <div class="col-auto">
                    <button type="submit" class="btn btn-secondary btn-sm">Filter</button>
                    <a href="{{ route('hr.salary-components.index') }}" class="btn btn-outline-secondary btn-sm">Reset</a>
                </div>
            </form>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-sm mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Code</th>
                            <th>Name</th>
                            <th>Type</th>
                            <th>Calculation</th>
                            <th class="text-center">Taxable</th>
                            <th class="text-center">Affects</th>
                            <th class="text-center">Status</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($components as $component)
                            <tr>
                                <td><code>{{ $component->code }}</code></td>
                                <td>
                                    {{ $component->name }}
                                    @if($component->is_statutory)
                                        <span class="badge bg-warning text-dark ms-1">Statutory</span>
                                    @endif
                                </td>
                                <td>
                                    @if($component->type === 'earning')
                                        <span class="badge bg-success">Earning</span>
                                    @elseif($component->type === 'deduction')
                                        <span class="badge bg-danger">Deduction</span>
                                    @else
                                        <span class="badge bg-info">Employer</span>
                                    @endif
                                </td>
                                <td>
                                    @if($component->calculation_type === 'fixed')
                                        <span class="text-muted">Fixed</span>
                                    @elseif($component->calculation_type === 'percentage')
                                        {{ $component->percentage }}% of {{ ucfirst($component->based_on) }}
                                    @else
                                        <span class="text-muted">Formula</span>
                                    @endif
                                </td>
                                <td class="text-center">
                                    @if($component->is_taxable)
                                        <i class="bi bi-check-circle-fill text-success"></i>
                                    @else
                                        <i class="bi bi-x-circle text-muted"></i>
                                    @endif
                                </td>
                                <td class="text-center">
                                    @if($component->affects_pf)
                                        <span class="badge bg-light text-dark" title="Affects PF">PF</span>
                                    @endif
                                    @if($component->affects_esi)
                                        <span class="badge bg-light text-dark" title="Affects ESI">ESI</span>
                                    @endif
                                    @if($component->affects_pt)
                                        <span class="badge bg-light text-dark" title="Affects PT">PT</span>
                                    @endif
                                </td>
                                <td class="text-center">
                                    @if($component->is_active)
                                        <span class="badge bg-success">Active</span>
                                    @else
                                        <span class="badge bg-secondary">Inactive</span>
                                    @endif
                                </td>
                                <td class="text-end">
                                    <a href="{{ route('hr.salary-components.edit', $component) }}" 
                                       class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    @if(!$component->is_statutory)
                                        <form method="POST" action="{{ route('hr.salary-components.destroy', $component) }}" 
                                              class="d-inline" onsubmit="return confirm('Delete this component?')">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-sm btn-outline-danger">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    @endif
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="8" class="text-center text-muted py-4">No salary components found</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
        @if($components->hasPages())
            <div class="card-footer">
                {{ $components->links() }}
            </div>
        @endif
    </div>
</div>
@endsection
