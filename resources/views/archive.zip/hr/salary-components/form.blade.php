@extends('layouts.erp')

@section('title', isset($component) ? 'Edit Salary Component' : 'Add Salary Component')

@section('content')
<div class="container-fluid py-3">
    <div class="mb-3">
        <h4 class="mb-1">{{ isset($component) ? 'Edit Salary Component' : 'Add Salary Component' }}</h4>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0 small">
                <li class="breadcrumb-item"><a href="{{ route('hr.dashboard') }}">HR</a></li>
                <li class="breadcrumb-item"><a href="{{ route('hr.salary-components.index') }}">Salary Components</a></li>
                <li class="breadcrumb-item active">{{ isset($component) ? 'Edit' : 'Add' }}</li>
            </ol>
        </nav>
    </div>

    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">
                    <form method="POST" 
                          action="{{ isset($component) ? route('hr.salary-components.update', $component) : route('hr.salary-components.store') }}">
                        @csrf
                        @if(isset($component))
                            @method('PUT')
                        @endif

                        <div class="row mb-3">
                            <div class="col-md-3">
                                <label for="code" class="form-label">Code <span class="text-danger">*</span></label>
                                <input type="text" class="form-control @error('code') is-invalid @enderror" 
                                       id="code" name="code" 
                                       value="{{ old('code', $component->code ?? '') }}" 
                                       maxlength="20" required style="text-transform: uppercase;">
                                @error('code')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="col-md-6">
                                <label for="name" class="form-label">Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control @error('name') is-invalid @enderror" 
                                       id="name" name="name" 
                                       value="{{ old('name', $component->name ?? '') }}" 
                                       maxlength="100" required>
                                @error('name')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="col-md-3">
                                <label for="short_name" class="form-label">Short Name</label>
                                <input type="text" class="form-control @error('short_name') is-invalid @enderror" 
                                       id="short_name" name="short_name" 
                                       value="{{ old('short_name', $component->short_name ?? '') }}" 
                                       maxlength="20">
                                @error('short_name')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="type" class="form-label">Type <span class="text-danger">*</span></label>
                                <select class="form-select @error('type') is-invalid @enderror" id="type" name="type" required>
                                    <option value="">-- Select Type --</option>
                                    <option value="earning" {{ old('type', $component->type ?? '') === 'earning' ? 'selected' : '' }}>Earning</option>
                                    <option value="deduction" {{ old('type', $component->type ?? '') === 'deduction' ? 'selected' : '' }}>Deduction</option>
                                    <option value="employer_contribution" {{ old('type', $component->type ?? '') === 'employer_contribution' ? 'selected' : '' }}>Employer Contribution</option>
                                </select>
                                @error('type')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="col-md-6">
                                <label for="calculation_type" class="form-label">Calculation Type <span class="text-danger">*</span></label>
                                <select class="form-select @error('calculation_type') is-invalid @enderror" id="calculation_type" name="calculation_type" required>
                                    <option value="">-- Select --</option>
                                    <option value="fixed" {{ old('calculation_type', $component->calculation_type ?? '') === 'fixed' ? 'selected' : '' }}>Fixed Amount</option>
                                    <option value="percentage" {{ old('calculation_type', $component->calculation_type ?? '') === 'percentage' ? 'selected' : '' }}>Percentage</option>
                                    <option value="formula" {{ old('calculation_type', $component->calculation_type ?? '') === 'formula' ? 'selected' : '' }}>Formula</option>
                                </select>
                                @error('calculation_type')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div id="percentage_fields" class="row mb-3" style="{{ old('calculation_type', $component->calculation_type ?? '') === 'percentage' ? '' : 'display: none;' }}">
                            <div class="col-md-6">
                                <label for="percentage" class="form-label">Percentage (%)</label>
                                <input type="number" class="form-control @error('percentage') is-invalid @enderror" 
                                       id="percentage" name="percentage" 
                                       value="{{ old('percentage', $component->percentage ?? '') }}" 
                                       min="0" max="100" step="0.01">
                                @error('percentage')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="col-md-6">
                                <label for="based_on" class="form-label">Based On</label>
                                <select class="form-select @error('based_on') is-invalid @enderror" id="based_on" name="based_on">
                                    <option value="">-- Select --</option>
                                    <option value="basic" {{ old('based_on', $component->based_on ?? '') === 'basic' ? 'selected' : '' }}>Basic Salary</option>
                                    <option value="gross" {{ old('based_on', $component->based_on ?? '') === 'gross' ? 'selected' : '' }}>Gross Salary</option>
                                    <option value="ctc" {{ old('based_on', $component->based_on ?? '') === 'ctc' ? 'selected' : '' }}>CTC</option>
                                </select>
                                @error('based_on')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div id="formula_fields" class="mb-3" style="{{ old('calculation_type', $component->calculation_type ?? '') === 'formula' ? '' : 'display: none;' }}">
                            <label for="formula" class="form-label">Formula</label>
                            <input type="text" class="form-control @error('formula') is-invalid @enderror" 
                                   id="formula" name="formula" 
                                   value="{{ old('formula', $component->formula ?? '') }}" 
                                   placeholder="e.g., basic * 0.12">
                            @error('formula')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            <small class="text-muted">Use: basic, gross, ctc, hra, da as variables</small>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="min_limit" class="form-label">Minimum Limit (₹)</label>
                                <input type="number" class="form-control @error('min_limit') is-invalid @enderror" 
                                       id="min_limit" name="min_limit" 
                                       value="{{ old('min_limit', $component->min_limit ?? '') }}" 
                                       min="0" step="0.01">
                                @error('min_limit')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="col-md-6">
                                <label for="max_limit" class="form-label">Maximum Limit (₹)</label>
                                <input type="number" class="form-control @error('max_limit') is-invalid @enderror" 
                                       id="max_limit" name="max_limit" 
                                       value="{{ old('max_limit', $component->max_limit ?? '') }}" 
                                       min="0" step="0.01">
                                @error('max_limit')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <h6 class="border-bottom pb-2 mb-3">Tax & Statutory Settings</h6>

                        <div class="row mb-3">
                            <div class="col-md-4">
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" id="is_taxable" 
                                           name="is_taxable" value="1"
                                           {{ old('is_taxable', $component->is_taxable ?? false) ? 'checked' : '' }}>
                                    <label class="form-check-label" for="is_taxable">Taxable</label>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" id="is_statutory" 
                                           name="is_statutory" value="1"
                                           {{ old('is_statutory', $component->is_statutory ?? false) ? 'checked' : '' }}>
                                    <label class="form-check-label" for="is_statutory">Statutory Component</label>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" id="is_flexible" 
                                           name="is_flexible" value="1"
                                           {{ old('is_flexible', $component->is_flexible ?? false) ? 'checked' : '' }}>
                                    <label class="form-check-label" for="is_flexible">Flexible Benefit</label>
                                </div>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-4">
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" id="affects_pf" 
                                           name="affects_pf" value="1"
                                           {{ old('affects_pf', $component->affects_pf ?? false) ? 'checked' : '' }}>
                                    <label class="form-check-label" for="affects_pf">Affects PF Calculation</label>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" id="affects_esi" 
                                           name="affects_esi" value="1"
                                           {{ old('affects_esi', $component->affects_esi ?? false) ? 'checked' : '' }}>
                                    <label class="form-check-label" for="affects_esi">Affects ESI Calculation</label>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" id="affects_pt" 
                                           name="affects_pt" value="1"
                                           {{ old('affects_pt', $component->affects_pt ?? false) ? 'checked' : '' }}>
                                    <label class="form-check-label" for="affects_pt">Affects PT Calculation</label>
                                </div>
                            </div>
                        </div>

                        <h6 class="border-bottom pb-2 mb-3">Display Settings</h6>

                        <div class="row mb-3">
                            <div class="col-md-4">
                                <label for="sort_order" class="form-label">Sort Order</label>
                                <input type="number" class="form-control @error('sort_order') is-invalid @enderror" 
                                       id="sort_order" name="sort_order" 
                                       value="{{ old('sort_order', $component->sort_order ?? 0) }}" 
                                       min="0">
                                @error('sort_order')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="col-md-4">
                                <div class="form-check mt-4">
                                    <input type="checkbox" class="form-check-input" id="show_in_payslip" 
                                           name="show_in_payslip" value="1"
                                           {{ old('show_in_payslip', $component->show_in_payslip ?? true) ? 'checked' : '' }}>
                                    <label class="form-check-label" for="show_in_payslip">Show in Payslip</label>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-check mt-4">
                                    <input type="checkbox" class="form-check-input" id="is_active" 
                                           name="is_active" value="1"
                                           {{ old('is_active', $component->is_active ?? true) ? 'checked' : '' }}>
                                    <label class="form-check-label" for="is_active">Active</label>
                                </div>
                            </div>
                        </div>

                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-check-lg me-1"></i> 
                                {{ isset($component) ? 'Update' : 'Create' }}
                            </button>
                            <a href="{{ route('hr.salary-components.index') }}" class="btn btn-outline-secondary">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
document.getElementById('calculation_type').addEventListener('change', function() {
    document.getElementById('percentage_fields').style.display = this.value === 'percentage' ? '' : 'none';
    document.getElementById('formula_fields').style.display = this.value === 'formula' ? '' : 'none';
});
</script>
@endpush
@endsection
