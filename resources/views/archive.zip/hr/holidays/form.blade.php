@extends('layouts.erp')

@section('title', isset($holiday) ? 'Edit Holiday' : 'Add Holiday')

@section('content')
<div class="container-fluid py-3">
    <div class="mb-3">
        <h4 class="mb-1">{{ isset($holiday) ? 'Edit Holiday' : 'Add Holiday' }}</h4>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0 small">
                <li class="breadcrumb-item"><a href="{{ route('hr.dashboard') }}">HR</a></li>
                <li class="breadcrumb-item"><a href="{{ route('hr.holiday-calendars.index') }}">Holidays</a></li>
                <li class="breadcrumb-item active">{{ isset($holiday) ? 'Edit' : 'Add' }}</li>
            </ol>
        </nav>
    </div>

    <div class="row">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-body">
                    <form method="POST" 
                          action="{{ isset($holiday) ? route('hr.holiday-calendars.update', $holiday) : route('hr.holiday-calendars.store') }}">
                        @csrf
                        @if(isset($holiday))
                            @method('PUT')
                        @endif

                        <div class="mb-3">
                            <label for="name" class="form-label">Holiday Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control @error('name') is-invalid @enderror" 
                                   id="name" name="name" 
                                   value="{{ old('name', $holiday->name ?? '') }}" 
                                   maxlength="100" required>
                            @error('name')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="date" class="form-label">Date <span class="text-danger">*</span></label>
                                <input type="date" class="form-control @error('date') is-invalid @enderror" 
                                       id="date" name="date" 
                                       value="{{ old('date', isset($holiday) ? $holiday->date->format('Y-m-d') : '') }}" 
                                       required>
                                @error('date')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="col-md-6">
                                <label for="day_type" class="form-label">Day Type <span class="text-danger">*</span></label>
                                <select class="form-select @error('day_type') is-invalid @enderror" id="day_type" name="day_type" required>
                                    <option value="full_day" {{ old('day_type', $holiday->day_type ?? 'full_day') === 'full_day' ? 'selected' : '' }}>Full Day</option>
                                    <option value="half_day" {{ old('day_type', $holiday->day_type ?? '') === 'half_day' ? 'selected' : '' }}>Half Day</option>
                                </select>
                                @error('day_type')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control @error('description') is-invalid @enderror" 
                                      id="description" name="description" 
                                      rows="2" maxlength="500">{{ old('description', $holiday->description ?? '') }}</textarea>
                            @error('description')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" id="is_mandatory" 
                                           name="is_mandatory" value="1"
                                           {{ old('is_mandatory', $holiday->is_mandatory ?? true) ? 'checked' : '' }}>
                                    <label class="form-check-label" for="is_mandatory">
                                        Mandatory Holiday
                                    </label>
                                    <small class="text-muted d-block">Applicable to all employees</small>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" id="is_restricted" 
                                           name="is_restricted" value="1"
                                           {{ old('is_restricted', $holiday->is_restricted ?? false) ? 'checked' : '' }}>
                                    <label class="form-check-label" for="is_restricted">
                                        Restricted Holiday
                                    </label>
                                    <small class="text-muted d-block">Optional, employees can choose</small>
                                </div>
                            </div>
                        </div>

                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-check-lg me-1"></i> 
                                {{ isset($holiday) ? 'Update' : 'Create' }}
                            </button>
                            <a href="{{ route('hr.holiday-calendars.index') }}" class="btn btn-outline-secondary">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="card">
                <div class="card-header">
                    <h6 class="mb-0">Common Holidays (Reference)</h6>
                </div>
                <div class="card-body">
                    <div class="list-group list-group-flush small">
                        <div class="list-group-item d-flex justify-content-between">
                            <span>Republic Day</span>
                            <span class="text-muted">26 January</span>
                        </div>
                        <div class="list-group-item d-flex justify-content-between">
                            <span>Holi</span>
                            <span class="text-muted">Variable</span>
                        </div>
                        <div class="list-group-item d-flex justify-content-between">
                            <span>Good Friday</span>
                            <span class="text-muted">Variable</span>
                        </div>
                        <div class="list-group-item d-flex justify-content-between">
                            <span>Independence Day</span>
                            <span class="text-muted">15 August</span>
                        </div>
                        <div class="list-group-item d-flex justify-content-between">
                            <span>Gandhi Jayanti</span>
                            <span class="text-muted">2 October</span>
                        </div>
                        <div class="list-group-item d-flex justify-content-between">
                            <span>Dussehra</span>
                            <span class="text-muted">Variable</span>
                        </div>
                        <div class="list-group-item d-flex justify-content-between">
                            <span>Diwali</span>
                            <span class="text-muted">Variable</span>
                        </div>
                        <div class="list-group-item d-flex justify-content-between">
                            <span>Christmas</span>
                            <span class="text-muted">25 December</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
