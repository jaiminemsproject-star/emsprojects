@extends('layouts.erp')

@section('title', 'Holidays')

@section('content')
<div class="container-fluid py-3">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h4 class="mb-1">Holiday Calendar - {{ $year }}</h4>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 small">
                    <li class="breadcrumb-item"><a href="{{ route('hr.dashboard') }}">HR</a></li>
                    <li class="breadcrumb-item active">Holidays</li>
                </ol>
            </nav>
        </div>
        <div class="d-flex gap-2">
            <form method="GET" class="d-flex gap-2">
                <select name="year" class="form-select form-select-sm" onchange="this.form.submit()">
                    @foreach($years as $y)
                        <option value="{{ $y }}" {{ $y == $year ? 'selected' : '' }}>{{ $y }}</option>
                    @endforeach
                </select>
            </form>
            <a href="{{ route('hr.holiday-calendars.create') }}" class="btn btn-primary btn-sm">
                <i class="bi bi-plus-lg me-1"></i> Add Holiday
            </a>
        </div>
    </div>

    @include('partials.flash')

    {{-- Stats --}}
    <div class="row mb-3">
        <div class="col-md-4">
            <div class="card bg-light">
                <div class="card-body py-2 text-center">
                    <h4 class="mb-0">{{ $stats['total'] }}</h4>
                    <small class="text-muted">Total Holidays</small>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-success bg-opacity-10">
                <div class="card-body py-2 text-center">
                    <h4 class="mb-0 text-success">{{ $stats['mandatory'] }}</h4>
                    <small class="text-muted">Mandatory</small>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-info bg-opacity-10">
                <div class="card-body py-2 text-center">
                    <h4 class="mb-0 text-info">{{ $stats['optional'] }}</h4>
                    <small class="text-muted">Optional/Restricted</small>
                </div>
            </div>
        </div>
    </div>

    {{-- Holiday List by Month --}}
    @forelse($holidays as $month => $monthHolidays)
        <div class="card mb-3">
            <div class="card-header bg-light py-2">
                <h6 class="mb-0">{{ $month }}</h6>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover table-sm mb-0">
                        <thead class="table-light">
                            <tr>
                                <th style="width: 100px;">Date</th>
                                <th style="width: 80px;">Day</th>
                                <th>Holiday Name</th>
                                <th class="text-center" style="width: 100px;">Type</th>
                                <th class="text-center" style="width: 100px;">Day Type</th>
                                <th class="text-end" style="width: 120px;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($monthHolidays as $holiday)
                                <tr>
                                    <td>{{ $holiday->date->format('d M Y') }}</td>
                                    <td>{{ $holiday->date->format('D') }}</td>
                                    <td>
                                        {{ $holiday->name }}
                                        @if($holiday->description)
                                            <small class="text-muted d-block">{{ $holiday->description }}</small>
                                        @endif
                                    </td>
                                    <td class="text-center">
                                        @if($holiday->is_mandatory)
                                            <span class="badge bg-success">Mandatory</span>
                                        @elseif($holiday->is_restricted)
                                            <span class="badge bg-warning text-dark">Restricted</span>
                                        @else
                                            <span class="badge bg-secondary">Optional</span>
                                        @endif
                                    </td>
                                    <td class="text-center">
                                        @if($holiday->day_type === 'half_day')
                                            <span class="badge bg-info">Half Day</span>
                                        @else
                                            <span class="badge bg-primary">Full Day</span>
                                        @endif
                                    </td>
                                    <td class="text-end">
                                        <a href="{{ route('hr.holiday-calendars.edit', $holiday) }}" 
                                           class="btn btn-sm btn-outline-primary">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                        <form method="POST" action="{{ route('hr.holiday-calendars.destroy', $holiday) }}" 
                                              class="d-inline" onsubmit="return confirm('Delete this holiday?')">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-sm btn-outline-danger">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    @empty
        <div class="card">
            <div class="card-body text-center py-5">
                <i class="bi bi-calendar-x display-4 text-muted"></i>
                <p class="text-muted mt-3">No holidays defined for {{ $year }}</p>
                <a href="{{ route('hr.holiday-calendars.create') }}" class="btn btn-primary">
                    <i class="bi bi-plus-lg me-1"></i> Add First Holiday
                </a>
            </div>
        </div>
    @endforelse

    {{-- Copy to Next Year --}}
    @if($holidays->count() > 0)
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <span class="text-muted">Copy holidays to next year (dates will be adjusted)</span>
                    <form method="POST" action="{{ route('hr.holiday-calendars.index') }}?copy_year={{ $year }}" 
                          onsubmit="return confirm('Copy all {{ $year }} holidays to {{ $year + 1 }}?')">
                        @csrf
                        <input type="hidden" name="from_year" value="{{ $year }}">
                        <button type="submit" class="btn btn-outline-secondary btn-sm" formaction="{{ route('hr.holiday-calendars.index') }}?action=copy">
                            <i class="bi bi-copy me-1"></i> Copy to {{ $year + 1 }}
                        </button>
                    </form>
                </div>
            </div>
        </div>
    @endif
</div>
@endsection
