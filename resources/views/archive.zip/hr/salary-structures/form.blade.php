@extends('layouts.erp')

@section('title', isset($structure) ? 'Edit Salary Structure' : 'Add Salary Structure')

@section('content')
<div class="container-fluid py-3">
    <div class="mb-3">
        <h4 class="mb-1">{{ isset($structure) ? 'Edit Salary Structure' : 'Add Salary Structure' }}</h4>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0 small">
                <li class="breadcrumb-item"><a href="{{ route('hr.dashboard') }}">HR</a></li>
                <li class="breadcrumb-item"><a href="{{ route('hr.salary-structures.index') }}">Salary Structures</a></li>
                <li class="breadcrumb-item active">{{ isset($structure) ? 'Edit' : 'Add' }}</li>
            </ol>
        </nav>
    </div>

    <form method="POST" 
          action="{{ isset($structure) ? route('hr.salary-structures.update', $structure) : route('hr.salary-structures.store') }}"
          id="structureForm">
        @csrf
        @if(isset($structure))
            @method('PUT')
        @endif

        <div class="row">
            <div class="col-lg-4">
                {{-- Basic Info --}}
                <div class="card mb-3">
                    <div class="card-header">
                        <h6 class="mb-0">Basic Information</h6>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label for="code" class="form-label">Code <span class="text-danger">*</span></label>
                            <input type="text" class="form-control @error('code') is-invalid @enderror" 
                                   id="code" name="code" 
                                   value="{{ old('code', $structure->code ?? '') }}" 
                                   maxlength="20" required style="text-transform: uppercase;">
                            @error('code')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label for="name" class="form-label">Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control @error('name') is-invalid @enderror" 
                                   id="name" name="name" 
                                   value="{{ old('name', $structure->name ?? '') }}" 
                                   maxlength="100" required>
                            @error('name')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control @error('description') is-invalid @enderror" 
                                      id="description" name="description" 
                                      rows="3" maxlength="500">{{ old('description', $structure->description ?? '') }}</textarea>
                            @error('description')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" id="is_active" 
                                   name="is_active" value="1"
                                   {{ old('is_active', $structure->is_active ?? true) ? 'checked' : '' }}>
                            <label class="form-check-label" for="is_active">Active</label>
                        </div>
                    </div>
                </div>

                {{-- Actions --}}
                <div class="card">
                    <div class="card-body">
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-check-lg me-1"></i> 
                                {{ isset($structure) ? 'Update Structure' : 'Create Structure' }}
                            </button>
                            <a href="{{ route('hr.salary-structures.index') }}" class="btn btn-outline-secondary">Cancel</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-8">
                {{-- Components --}}
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h6 class="mb-0">Salary Components</h6>
                        <span class="badge bg-secondary" id="componentCount">0 selected</span>
                    </div>
                    <div class="card-body">
                        @if(isset($components['earning']) && $components['earning']->count())
                            <h6 class="text-success mb-2">
                                <i class="bi bi-plus-circle me-1"></i> Earnings
                            </h6>
                            <div class="table-responsive mb-4">
                                <table class="table table-sm table-bordered">
                                    <thead class="table-light">
                                        <tr>
                                            <th style="width: 30px;"></th>
                                            <th>Component</th>
                                            <th style="width: 150px;">Calculation</th>
                                            <th style="width: 120px;">Value</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($components['earning'] as $comp)
                                            @php
                                                $existingComp = isset($structure) ? $structure->components->firstWhere('id', $comp->id) : null;
                                                $isSelected = $existingComp || old("components.{$comp->id}.id");
                                            @endphp
                                            <tr>
                                                <td class="text-center">
                                                    <input type="checkbox" class="form-check-input component-checkbox" 
                                                           data-component-id="{{ $comp->id }}"
                                                           {{ $isSelected ? 'checked' : '' }}>
                                                </td>
                                                <td>
                                                    {{ $comp->name }} <code class="text-muted small">({{ $comp->code }})</code>
                                                    @if($comp->is_statutory)
                                                        <span class="badge bg-warning text-dark">Statutory</span>
                                                    @endif
                                                </td>
                                                <td>
                                                    <select class="form-select form-select-sm component-calc" 
                                                            data-component-id="{{ $comp->id }}" 
                                                            {{ $isSelected ? '' : 'disabled' }}>
                                                        <option value="fixed" {{ ($existingComp->pivot->calculation_type ?? $comp->calculation_type) === 'fixed' ? 'selected' : '' }}>Fixed</option>
                                                        <option value="percentage" {{ ($existingComp->pivot->calculation_type ?? $comp->calculation_type) === 'percentage' ? 'selected' : '' }}>Percentage</option>
                                                    </select>
                                                </td>
                                                <td>
                                                    <div class="input-group input-group-sm">
                                                        <input type="number" class="form-control component-amount" 
                                                               data-component-id="{{ $comp->id }}"
                                                               value="{{ $existingComp->pivot->amount ?? $existingComp->pivot->percentage ?? '' }}"
                                                               step="0.01" min="0" {{ $isSelected ? '' : 'disabled' }}>
                                                        <span class="input-group-text component-suffix" data-component-id="{{ $comp->id }}">
                                                            {{ ($existingComp->pivot->calculation_type ?? $comp->calculation_type) === 'percentage' ? '%' : '₹' }}
                                                        </span>
                                                    </div>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        @endif

                        @if(isset($components['deduction']) && $components['deduction']->count())
                            <h6 class="text-danger mb-2">
                                <i class="bi bi-dash-circle me-1"></i> Deductions
                            </h6>
                            <div class="table-responsive mb-4">
                                <table class="table table-sm table-bordered">
                                    <thead class="table-light">
                                        <tr>
                                            <th style="width: 30px;"></th>
                                            <th>Component</th>
                                            <th style="width: 150px;">Calculation</th>
                                            <th style="width: 120px;">Value</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($components['deduction'] as $comp)
                                            @php
                                                $existingComp = isset($structure) ? $structure->components->firstWhere('id', $comp->id) : null;
                                                $isSelected = $existingComp || old("components.{$comp->id}.id");
                                            @endphp
                                            <tr>
                                                <td class="text-center">
                                                    <input type="checkbox" class="form-check-input component-checkbox" 
                                                           data-component-id="{{ $comp->id }}"
                                                           {{ $isSelected ? 'checked' : '' }}>
                                                </td>
                                                <td>
                                                    {{ $comp->name }} <code class="text-muted small">({{ $comp->code }})</code>
                                                    @if($comp->is_statutory)
                                                        <span class="badge bg-warning text-dark">Statutory</span>
                                                    @endif
                                                </td>
                                                <td>
                                                    <select class="form-select form-select-sm component-calc" 
                                                            data-component-id="{{ $comp->id }}" 
                                                            {{ $isSelected ? '' : 'disabled' }}>
                                                        <option value="fixed" {{ ($existingComp->pivot->calculation_type ?? $comp->calculation_type) === 'fixed' ? 'selected' : '' }}>Fixed</option>
                                                        <option value="percentage" {{ ($existingComp->pivot->calculation_type ?? $comp->calculation_type) === 'percentage' ? 'selected' : '' }}>Percentage</option>
                                                    </select>
                                                </td>
                                                <td>
                                                    <div class="input-group input-group-sm">
                                                        <input type="number" class="form-control component-amount" 
                                                               data-component-id="{{ $comp->id }}"
                                                               value="{{ $existingComp->pivot->amount ?? $existingComp->pivot->percentage ?? '' }}"
                                                               step="0.01" min="0" {{ $isSelected ? '' : 'disabled' }}>
                                                        <span class="input-group-text component-suffix" data-component-id="{{ $comp->id }}">
                                                            {{ ($existingComp->pivot->calculation_type ?? $comp->calculation_type) === 'percentage' ? '%' : '₹' }}
                                                        </span>
                                                    </div>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        @endif

                        @if(isset($components['employer_contribution']) && $components['employer_contribution']->count())
                            <h6 class="text-info mb-2">
                                <i class="bi bi-building me-1"></i> Employer Contributions
                            </h6>
                            <div class="table-responsive">
                                <table class="table table-sm table-bordered">
                                    <thead class="table-light">
                                        <tr>
                                            <th style="width: 30px;"></th>
                                            <th>Component</th>
                                            <th style="width: 150px;">Calculation</th>
                                            <th style="width: 120px;">Value</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($components['employer_contribution'] as $comp)
                                            @php
                                                $existingComp = isset($structure) ? $structure->components->firstWhere('id', $comp->id) : null;
                                                $isSelected = $existingComp || old("components.{$comp->id}.id");
                                            @endphp
                                            <tr>
                                                <td class="text-center">
                                                    <input type="checkbox" class="form-check-input component-checkbox" 
                                                           data-component-id="{{ $comp->id }}"
                                                           {{ $isSelected ? 'checked' : '' }}>
                                                </td>
                                                <td>
                                                    {{ $comp->name }} <code class="text-muted small">({{ $comp->code }})</code>
                                                    @if($comp->is_statutory)
                                                        <span class="badge bg-warning text-dark">Statutory</span>
                                                    @endif
                                                </td>
                                                <td>
                                                    <select class="form-select form-select-sm component-calc" 
                                                            data-component-id="{{ $comp->id }}" 
                                                            {{ $isSelected ? '' : 'disabled' }}>
                                                        <option value="fixed" {{ ($existingComp->pivot->calculation_type ?? $comp->calculation_type) === 'fixed' ? 'selected' : '' }}>Fixed</option>
                                                        <option value="percentage" {{ ($existingComp->pivot->calculation_type ?? $comp->calculation_type) === 'percentage' ? 'selected' : '' }}>Percentage</option>
                                                    </select>
                                                </td>
                                                <td>
                                                    <div class="input-group input-group-sm">
                                                        <input type="number" class="form-control component-amount" 
                                                               data-component-id="{{ $comp->id }}"
                                                               value="{{ $existingComp->pivot->amount ?? $existingComp->pivot->percentage ?? '' }}"
                                                               step="0.01" min="0" {{ $isSelected ? '' : 'disabled' }}>
                                                        <span class="input-group-text component-suffix" data-component-id="{{ $comp->id }}">
                                                            {{ ($existingComp->pivot->calculation_type ?? $comp->calculation_type) === 'percentage' ? '%' : '₹' }}
                                                        </span>
                                                    </div>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        @endif

                        {{-- Hidden inputs for form submission --}}
                        <div id="componentInputs"></div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('structureForm');
    const componentInputs = document.getElementById('componentInputs');
    
    function updateComponentCount() {
        const count = document.querySelectorAll('.component-checkbox:checked').length;
        document.getElementById('componentCount').textContent = count + ' selected';
    }
    
    function updateSuffix(componentId) {
        const calcType = document.querySelector(`.component-calc[data-component-id="${componentId}"]`).value;
        const suffix = document.querySelector(`.component-suffix[data-component-id="${componentId}"]`);
        suffix.textContent = calcType === 'percentage' ? '%' : '₹';
    }
    
    // Handle checkbox changes
    document.querySelectorAll('.component-checkbox').forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            const componentId = this.dataset.componentId;
            const calcSelect = document.querySelector(`.component-calc[data-component-id="${componentId}"]`);
            const amountInput = document.querySelector(`.component-amount[data-component-id="${componentId}"]`);
            
            calcSelect.disabled = !this.checked;
            amountInput.disabled = !this.checked;
            
            updateComponentCount();
        });
    });
    
    // Handle calculation type changes
    document.querySelectorAll('.component-calc').forEach(select => {
        select.addEventListener('change', function() {
            updateSuffix(this.dataset.componentId);
        });
    });
    
    // On form submit, build hidden inputs
    form.addEventListener('submit', function(e) {
        componentInputs.innerHTML = '';
        let index = 0;
        
        document.querySelectorAll('.component-checkbox:checked').forEach(checkbox => {
            const componentId = checkbox.dataset.componentId;
            const calcType = document.querySelector(`.component-calc[data-component-id="${componentId}"]`).value;
            const amount = document.querySelector(`.component-amount[data-component-id="${componentId}"]`).value;
            
            componentInputs.innerHTML += `
                <input type="hidden" name="components[${index}][id]" value="${componentId}">
                <input type="hidden" name="components[${index}][calculation_type]" value="${calcType}">
                <input type="hidden" name="components[${index}][${calcType === 'percentage' ? 'percentage' : 'amount'}]" value="${amount}">
                <input type="hidden" name="components[${index}][based_on]" value="basic">
            `;
            index++;
        });
        
        if (index === 0) {
            e.preventDefault();
            alert('Please select at least one salary component.');
        }
    });
    
    updateComponentCount();
});
</script>
@endpush
@endsection
